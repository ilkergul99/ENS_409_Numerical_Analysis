function jacobi
    disp('------- Jacobi Iterative Method -------')
    A = [1 -1 1 -1;
    -1 3 -3 3;
    2 -4 7 -7;
    3 7 -10 14];

    b = [0 2 -2 -8]';
    X0 = [0,0, -0.5, -0.5]';
    exact_result = A\b;
    D = eye(4);
    for i = 1:4
        D(i,i) = A(i,i);
    end
    disp('Diagonal matrix of Jacobi:');
    disp(D);
    
    L = zeros(4,4);
    L(2,1) = -A(2,1);
    L(3,1) = -A(3,1);
    L(3,2) = -A(3,2);
    L(4,1) = -A(4,1);
    L(4,2) = -A(4,2);
    L(4,3) = -A(4,3);
    disp('Lower Triangular matrix of Jacobi:');
    disp(L);
    
    U = zeros(4,4);
    U(1,2) = -A(1,2);
    U(1,3) = -A(1,3);
    U(1,4) = -A(1,4);
    U(2,3) = -A(2,3);
    U(2,4) = -A(2,4);
    U(3,4) = -A(3,4);
    disp('Upper Triangular matrix of Jacobi:');
    disp(U);
    
    tol = 1;
    iter = 0;
    temp = L+ U;
    JacobiEstimate = [];
    while (tol > 10^(-6) && iter < 71)
        iter = iter + 1;
        JacobiEstimate = D\temp*X0 + D\b;
        Error = abs(X0 - JacobiEstimate)./abs(JacobiEstimate);
%         disp(iter)
%         disp('Absoulute error of each variable with respect to exact value by the \ operation:')
%         disp(Error);
        tol = max(Error);
        X0 = JacobiEstimate;
        
    end
    if(iter ~= 71)
        disp('Iteration number is as follows:'); 
        disp(iter);
    end
    disp('Jacobi estimate values are as follows:');
    disp(JacobiEstimate);
end