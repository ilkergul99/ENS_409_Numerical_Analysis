function gauss_seidel
    disp('------- Gauss-Seidel -------')
    A = [1 -1 1 -1;
    -1 3 -3 3;
    2 -4 7 -7;
    3 7 -10 14];

    b = [0 2 -2 -8]';
    exact_result = A\b;
    tol = 1;
    iter = 1;
    X = zeros(4,30);
    X(:,1) = [0,0, -0.5, -0.5]';
    while (tol > 10^(-6) && iter < 71)
        iter = iter + 1;
        X(1,iter) = (b(1)-(A(1,2)*X(2, iter -1))-(A(1,3)*X(3, iter -1))- (A(1,4)*X(4, iter -1)))/A(1,1);
        X(2,iter) = (b(2)-(A(2,1)*X(1, iter))-(A(2,3)*X(3, iter -1))- (A(2,4)*X(4, iter -1)))/A(2,2);
        X(3,iter) = (b(3)-(A(3,1)*X(1, iter))-(A(3,2)*X(2, iter))- (A(3,4)*X(4, iter -1)))/A(3,3);
        X(4,iter) = (b(4)-(A(4,1)*X(1, iter))-(A(4,2)*X(2, iter))- (A(4,3)*X(3, iter)))/A(4,4);
        Error = abs(X(:,iter-1) - X(:,iter))./abs(X(:,iter));
        
%         disp(iter -1);
%         disp('Absoulute error of each variable with respect to exact value by the \ operation:')
%         disp(Error);

        tol = max(Error);
    end
    if(iter ~= 71)
        disp('Iteration number is as follows:'); 
        disp(iter);
    end
    disp('Gauss-Seidel estimate values are as follows:');
    disp(X(:,iter));

end