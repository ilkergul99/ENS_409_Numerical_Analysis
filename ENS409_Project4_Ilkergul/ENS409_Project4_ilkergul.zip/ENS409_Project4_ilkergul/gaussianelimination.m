function gaussianelimination
    A = [1 -1 1 -1;
    -1 3 -3 3;
    2 -4 7 -7;
    3 7 -10 14];

    b = [0 2 -2 -8]';
    augmented_matrix = [A, b];
    % Initially, we need to perform forward elimination
    % in order to receive the coefficients of unknown for backward
    % substitution
    disp('------- Gaussian Elimination -------')
    disp('augmented matrix before forward elimination:')
    disp(augmented_matrix)
    for iterorder = 1:4
    rowcoefficient = augmented_matrix(iterorder,iterorder);
       if iterorder ~= 4
          for remaining = iterorder+1:4
             itereliminationnumber = augmented_matrix(remaining,iterorder);
             eliminationcoeff = (itereliminationnumber/rowcoefficient)*(-1);
             subtractionrow = augmented_matrix(iterorder,:).*eliminationcoeff;
             augmented_matrix(remaining,:) = augmented_matrix(remaining,:)+subtractionrow;
          end
       end
    end
    
    % Now, we can proceed with the back substitution
    value_vector = zeros(4, 1);
    value_vector(4,1) = augmented_matrix(4, 5)/augmented_matrix(4, 4); 
    for i = 3:-1:1
        sum = 0;
        for j = 1:4
             sum = sum + augmented_matrix(i,j)*value_vector(j,1);
        end 
        eq_result = augmented_matrix(i,5);
        x_entry = (eq_result - sum)/augmented_matrix(i,i);
        value_vector(i,1) = x_entry;
    end
    disp('augmented matrix after forward elimination:')
    disp(augmented_matrix)
    disp('solution for the system is as follows:')
    disp(value_vector);
      
end