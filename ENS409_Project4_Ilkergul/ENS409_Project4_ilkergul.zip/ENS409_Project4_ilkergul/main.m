clear;
clc;

A = [1 -1 1 -1;
    -1 3 -3 3;
    2 -4 7 -7;
    3 7 -10 14];

b = [0 2 -2 -8]';
result = A\b;
fprintf("Exact result by the \\ operation:\n")
disp(result);
gaussianelimination;
fprintf("\n")
ludecomposition;
fprintf("\n")
jacobi;
fprintf("\n")
gauss_seidel;
