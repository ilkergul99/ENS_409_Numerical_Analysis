clear;
clc;

Tempx = [];
Tempy = [];
Tempxg = [];
Tempyg = [];

count = 0;
while count < 8
    count = count + 1;
    m = input('Please enter the iteration number:');

    A = zeros(m,m);
    fprintf('\n');
    for i = 1:m
        if(i == 1)
            A(i,i) = 2;
            A(i,i+1) = -1;
        elseif(i == m)
            A(i,i-1) = -1;
            A(i,i) = 2;
        else
            A(i,i-1) = -1;
            A(i,i) = 2;
            A(i,i+1) = -1;
        end
    end
    b = zeros(m,1);
    b(1,1) = 1;
    b(m,1) = 1;
    result = A\b;
    fprintf("Exact result by the \\ operation:\n")
    disp(result);
    gaussianelimination_q3(A,b)
    fprintf("\n")
    ludecomposition_q3(A,b);
    fprintf("\n")
    [t1,t2] = jacobi_q3(A,b);
    fprintf("\n")
    [t3,t4] = gauss_seidel_q3(A,b);

    Tempx = [Tempx; t1];
    Tempy = [Tempy; t2];
    Tempxg = [Tempxg; t3];
    Tempyg = [Tempyg; t4];
    
end

plot(Tempx, Tempy, 'DisplayName','Iteration Count of Jacobi');
hold on;
plot(Tempxg, Tempyg,'DisplayName','Iteration Count of Gauss-Seidel');
grid on;
legend;
