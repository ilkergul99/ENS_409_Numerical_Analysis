function [Tempx, Tempy] = jacobi_q3(A,b)
    disp('------- Jacobi Iterative Method -------')
    [row,col] = size(A);
    m = row;
    X0 = zeros(row,1);
    exact_result = A\b;
    D = eye(row);
    for i = 1:row
        D(i,i) = A(i,i);
    end
    disp('Diagonal matrix of Jacobi:');
    disp(D);
    
    L = zeros(row,row);
    for i = 1:row
        for j = i+1:row
            L(j,i) = -A(j,i);
        end
    end


    disp('Lower Triangular matrix of Jacobi:');
    disp(L);
    
    U = zeros(row,row);
    for i = 1:row
        for j = i+1:row
            U(i,j) = -A(i,j);
        end
    end
    disp('Upper Triangular matrix of Jacobi:');
    disp(U);
    
    tol = 1;
    iter = 0;
    temp = L+U;
    JacobiEstimate = [];

    while (tol > 10^(-4))
        iter = iter + 1;
        JacobiEstimate = D\temp*X0 + D\b;
        Error = abs(X0 - JacobiEstimate);
%         disp(iter)
%         disp('Relative Approximate error of each variable with respect to exact value by the \ operation:')
%         disp(Error);
        tol = max(Error);
        X0 = JacobiEstimate;   
    end
    Tempx = row;
    Tempy = iter;
    disp('Jacobi estimate values are as follows:');
    disp(JacobiEstimate);
end