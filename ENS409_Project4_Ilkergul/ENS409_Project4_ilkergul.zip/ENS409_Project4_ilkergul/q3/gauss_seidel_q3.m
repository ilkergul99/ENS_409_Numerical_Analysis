function [Tempx, Tempy] = gauss_seidel_q3(A,b)
    disp('------- Gauss-Seidel -------');
    [row,col] = size(A);
    exact_result = A\b;
    tol = 1;
    iter = 1;
    X = [];
    X(:,1) = zeros(row,1);
    while (tol > 10^(-4))
        iter = iter + 1;
        for i=1:row
            X(i,iter) = b(i);
            for j = 1:row
                if(i ~= j)
                    if(j<i)
                        X(i,iter) = X(i,iter)-(A(i,j)*X(j, iter));
                    else
                        X(i,iter) = X(i,iter)-(A(i,j)*X(j, iter-1));
                    end
                    
                end
            end
            X(i,iter) = X(i,iter)/A(i,i);
        end
        Error = abs(exact_result - X(:,iter));
        Relative_error = abs(X(:,iter-1)-X(:,iter));
%         disp(iter -1);
%         disp('Absoulute error of each variable with respect to exact value by the \\ operation:')
%         disp(Error);
%         disp('Relative error of each variable with respect to exact value by the \\ operation:')
%         disp(Relative_error);
        tol = max(Relative_error);
    end
    Tempx = row;
    Tempy = iter -1;
    if(iter ~= 51)
        disp('Iteration number is as follows:'); 
        disp(iter);
    end
    disp('Gauss-Seidel estimate values are as follows:');
    disp(X(:,iter));

end