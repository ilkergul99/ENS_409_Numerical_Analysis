function ludecomposition_q3(A,b)
    [row,col] = size(A);
    
    disp('------- LU Decomposition -------')
    Upper_triangular_matrix = A;
    Lower_triangular_matrix = eye(row);
    Uppercoefficients = [];
    %Now, we are going to perform LU decomposition
    %First, Find U
    for iterorder = 1:row
       rowcoefficient = Upper_triangular_matrix(iterorder,iterorder);
       if iterorder ~= row
          for remaining = iterorder+1:row
             itereliminationnumber = Upper_triangular_matrix(remaining,iterorder);
             eliminationcoeff = (itereliminationnumber/rowcoefficient)*(-1);
             Uppercoefficients = [Uppercoefficients; eliminationcoeff*(-1)];
             Lower_triangular_matrix(remaining,iterorder) = eliminationcoeff*(-1);
             subtractionrow = Upper_triangular_matrix(iterorder,:).*eliminationcoeff;
             Upper_triangular_matrix(remaining,:) = Upper_triangular_matrix(remaining,:)+subtractionrow;
          end
       end
    end
%     disp('Upper triangluar matrix after forward elimination:');
%     disp(Upper_triangular_matrix);
%     
%     disp('Lower triangluar matrix after finding forward elimination coefficients:');
%     disp(Lower_triangular_matrix);
    
    z_vector = zeros(row, 1);
    z_vector(1,1) = b(1,1)/Lower_triangular_matrix(1,1); 
    for i = 2:row
        sum = 0;
        for j = 1:i
             sum = sum + Lower_triangular_matrix(i,j)*z_vector(j,1);
        end 
        eq_result = b(i,1);
        x_entry = (eq_result - sum)/Lower_triangular_matrix(i,i);
        z_vector(i,1) = x_entry;
    end
    
    value_vector = zeros(row, 1);
    value_vector(row,1) = z_vector(row,1)/Upper_triangular_matrix(row,row); 
    for i = row-1:-1:1
        sum = 0;
        for j = 1:row
             sum = sum + Upper_triangular_matrix(i,j)*value_vector(j,1);
        end 
        eq_result = z_vector(i,1);
        x_entry = (eq_result - sum)/Upper_triangular_matrix(i,i);
        value_vector(i,1) = x_entry;
    end
    disp('solution after first step (z vector) is as follows:')
    disp(z_vector);
    disp('solution for the system is as follows:')
    disp(value_vector);

end