function gaussianelimination_q3(A,b)

    augmented_matrix = [A, b];
    [row,col] = size(A);
    % Initially, we need to perform forward elimination
    % in order to receive the coefficients of unknown for backward
    % substitution
    disp('------- Gaussian Elimination -------')
%     disp('augmented matrix before forward elimination:')
%     disp(augmented_matrix)
    for iterorder = 1:row
    rowcoefficient = augmented_matrix(iterorder,iterorder);
       if iterorder ~= row
          for remaining = iterorder+1:row
             itereliminationnumber = augmented_matrix(remaining,iterorder);
             eliminationcoeff = (itereliminationnumber/rowcoefficient)*(-1);
             subtractionrow = augmented_matrix(iterorder,:).*eliminationcoeff;
             augmented_matrix(remaining,:) = augmented_matrix(remaining,:)+subtractionrow;
          end
       end
    end
    
    % Now, we can proceed with the back substitution
    value_vector = zeros(row, 1);
    value_vector(row,1) = augmented_matrix(row, row+1)/augmented_matrix(row, row); 
    for i = row-1:-1:1
        sum = 0;
        for j = 1:row
             sum = sum + augmented_matrix(i,j)*value_vector(j,1);
        end 
        eq_result = augmented_matrix(i,row+1);
        x_entry = (eq_result - sum)/augmented_matrix(i,i);
        value_vector(i,1) = x_entry;
    end
%     disp('augmented matrix after forward elimination:')
%     disp(augmented_matrix)
    disp('solution for the system is as follows:')
    disp(value_vector);
      
end