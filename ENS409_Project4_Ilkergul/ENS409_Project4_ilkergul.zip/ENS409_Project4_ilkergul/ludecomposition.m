function ludecomposition
    
    disp('------- LU Decomposition -------')
    A = [1 -1 1 -1;
    -1 3 -3 3;
    2 -4 7 -7;
    3 7 -10 14];

    b = [0 2 -2 -8]';
    Upper_triangular_matrix = A;
    Lower_triangular_matrix = eye(4);
    Uppercoefficients = [];
    %Now, we are going to perform LU decomposition
    %First, Find U
    for iterorder = 1:4
    rowcoefficient = Upper_triangular_matrix(iterorder,iterorder);
       if iterorder ~= 4
          for remaining = iterorder+1:4
             itereliminationnumber = Upper_triangular_matrix(remaining,iterorder);
             eliminationcoeff = (itereliminationnumber/rowcoefficient)*(-1);
             Uppercoefficients = [Uppercoefficients; eliminationcoeff*(-1)];
             subtractionrow = Upper_triangular_matrix(iterorder,:).*eliminationcoeff;
             Upper_triangular_matrix(remaining,:) = Upper_triangular_matrix(remaining,:)+subtractionrow;
          end
       end
    end
    disp('Upper triangluar matrix after forward elimination:');
    disp(Upper_triangular_matrix);
    Lower_triangular_matrix(2,1) = Uppercoefficients(1);
    Lower_triangular_matrix(3,1) = Uppercoefficients(2);
    Lower_triangular_matrix(4,1) = Uppercoefficients(3);
    Lower_triangular_matrix(3,2) = Uppercoefficients(4);
    Lower_triangular_matrix(4,2) = Uppercoefficients(5);
    Lower_triangular_matrix(4,3) = Uppercoefficients(6);
    disp('Lower triangluar matrix after finding forward elimination coefficients:');
    disp(Lower_triangular_matrix);
    
    
    
    z_vector = zeros(4, 1);
    z_vector(1,1) = b(1,1)/Lower_triangular_matrix(1,1); 
    for i = 2:4
        sum = 0;
        for j = 1:i
             sum = sum + Lower_triangular_matrix(i,j)*z_vector(j,1);
        end 
        eq_result = b(i,1);
        x_entry = (eq_result - sum)/Lower_triangular_matrix(i,i);
        z_vector(i,1) = x_entry;
    end
    
    value_vector = zeros(4, 1);
    value_vector(4,1) = z_vector(4,1)/Upper_triangular_matrix(4,4); 
    for i = 3:-1:1
        sum = 0;
        for j = 1:4
             sum = sum + Upper_triangular_matrix(i,j)*value_vector(j,1);
        end 
        eq_result = z_vector(i,1);
        x_entry = (eq_result - sum)/Upper_triangular_matrix(i,i);
        value_vector(i,1) = x_entry;
    end
    disp('solution after first step (z vector) is as follows:')
    disp(z_vector);
    disp('solution for the system is as follows:')
    disp(value_vector);

end