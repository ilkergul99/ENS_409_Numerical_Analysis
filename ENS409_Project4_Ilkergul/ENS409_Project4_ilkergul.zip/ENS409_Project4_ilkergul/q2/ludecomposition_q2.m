function ludecomposition_q2(A,b)
    [row,col] = size(A);
    m = row;
    disp('------- LU Decomposition -------')
    Upper_triangular_matrix = A;
    Lower_triangular_matrix = eye(row);
    Uppercoefficients = [];
    %Now, we are going to perform LU decomposition
    %First, Find U
    for iterorder = 1:row
       rowcoefficient = Upper_triangular_matrix(iterorder,iterorder);
       if iterorder ~= row
          for remaining = iterorder+1:row
             itereliminationnumber = Upper_triangular_matrix(remaining,iterorder);
             eliminationcoeff = (itereliminationnumber/rowcoefficient)*(-1);
             Uppercoefficients = [Uppercoefficients; eliminationcoeff*(-1)];
             subtractionrow = Upper_triangular_matrix(iterorder,:).*eliminationcoeff;
             Upper_triangular_matrix(remaining,:) = Upper_triangular_matrix(remaining,:)+subtractionrow;
          end
       end
    end
    disp('Upper triangluar matrix after forward elimination:');
    disp(Upper_triangular_matrix);
    if(m == 3)
        Lower_triangular_matrix(2,1) = Uppercoefficients(1);
        Lower_triangular_matrix(3,1) = Uppercoefficients(2);
        Lower_triangular_matrix(3,2) = Uppercoefficients(3);
    end
    if(m == 7)
        Lower_triangular_matrix(2,1) = Uppercoefficients(1);
        Lower_triangular_matrix(3,1) = Uppercoefficients(2);
        Lower_triangular_matrix(4,1) = Uppercoefficients(3);
        Lower_triangular_matrix(5,1) = Uppercoefficients(4);
        Lower_triangular_matrix(6,1) = Uppercoefficients(5);
        Lower_triangular_matrix(7,1) = Uppercoefficients(6);
        Lower_triangular_matrix(3,2) = Uppercoefficients(7);
        Lower_triangular_matrix(4,2) = Uppercoefficients(8);
        Lower_triangular_matrix(5,2) = Uppercoefficients(9);
        Lower_triangular_matrix(6,2) = Uppercoefficients(10);
        Lower_triangular_matrix(7,2) = Uppercoefficients(11);
        Lower_triangular_matrix(4,3) = Uppercoefficients(12);
        Lower_triangular_matrix(5,3) = Uppercoefficients(13);
        Lower_triangular_matrix(6,3) = Uppercoefficients(14);
        Lower_triangular_matrix(7,3) = Uppercoefficients(15);
        Lower_triangular_matrix(5,4) = Uppercoefficients(16);
        Lower_triangular_matrix(6,4) = Uppercoefficients(17);
        Lower_triangular_matrix(7,4) = Uppercoefficients(18);
        Lower_triangular_matrix(6,5) = Uppercoefficients(19);
        Lower_triangular_matrix(7,5) = Uppercoefficients(20);
        Lower_triangular_matrix(7,6) = Uppercoefficients(21);
        
    end
    if(m == 9)
        Lower_triangular_matrix(2,1) = Uppercoefficients(1);
        Lower_triangular_matrix(3,1) = Uppercoefficients(2);
        Lower_triangular_matrix(4,1) = Uppercoefficients(3);
        Lower_triangular_matrix(5,1) = Uppercoefficients(4);
        Lower_triangular_matrix(6,1) = Uppercoefficients(5);
        Lower_triangular_matrix(7,1) = Uppercoefficients(6);
        Lower_triangular_matrix(8,1) = Uppercoefficients(7);
        Lower_triangular_matrix(9,1) = Uppercoefficients(8);
        
        Lower_triangular_matrix(3,2) = Uppercoefficients(9);
        Lower_triangular_matrix(4,2) = Uppercoefficients(10);
        Lower_triangular_matrix(5,2) = Uppercoefficients(11);
        Lower_triangular_matrix(6,2) = Uppercoefficients(12);
        Lower_triangular_matrix(7,2) = Uppercoefficients(13);
        Lower_triangular_matrix(8,2) = Uppercoefficients(14);
        Lower_triangular_matrix(9,2) = Uppercoefficients(15);
        
        Lower_triangular_matrix(4,3) = Uppercoefficients(16);
        Lower_triangular_matrix(5,3) = Uppercoefficients(17);
        Lower_triangular_matrix(6,3) = Uppercoefficients(18);
        Lower_triangular_matrix(7,3) = Uppercoefficients(19);
        Lower_triangular_matrix(8,3) = Uppercoefficients(20);
        Lower_triangular_matrix(9,3) = Uppercoefficients(21);
        
        Lower_triangular_matrix(5,4) = Uppercoefficients(22);
        Lower_triangular_matrix(6,4) = Uppercoefficients(23);
        Lower_triangular_matrix(7,4) = Uppercoefficients(24);
        Lower_triangular_matrix(8,4) = Uppercoefficients(25);
        Lower_triangular_matrix(9,4) = Uppercoefficients(26);

        Lower_triangular_matrix(6,5) = Uppercoefficients(27);
        Lower_triangular_matrix(7,5) = Uppercoefficients(28);
        Lower_triangular_matrix(8,5) = Uppercoefficients(29);
        Lower_triangular_matrix(9,5) = Uppercoefficients(30);
        
        Lower_triangular_matrix(7,6) = Uppercoefficients(31);
        Lower_triangular_matrix(8,6) = Uppercoefficients(32);
        Lower_triangular_matrix(9,6) = Uppercoefficients(33);
        Lower_triangular_matrix(8,7) = Uppercoefficients(34);
        Lower_triangular_matrix(9,7) = Uppercoefficients(35);
        Lower_triangular_matrix(9,8) = Uppercoefficients(36);
        
    end
    
    disp('Lower triangluar matrix after finding forward elimination coefficients:');
    disp(Lower_triangular_matrix);
    z_vector = zeros(row, 1);
    z_vector(1,1) = b(1,1)/Lower_triangular_matrix(1,1); 
    for i = 2:row
        sum = 0;
        for j = 1:i
             sum = sum + Lower_triangular_matrix(i,j)*z_vector(j,1);
        end 
        eq_result = b(i,1);
        x_entry = (eq_result - sum)/Lower_triangular_matrix(i,i);
        z_vector(i,1) = x_entry;
    end
    
    value_vector = zeros(row, 1);
    value_vector(row,1) = z_vector(row,1)/Upper_triangular_matrix(row,row); 
    for i = row-1:-1:1
        sum = 0;
        for j = 1:row
             sum = sum + Upper_triangular_matrix(i,j)*value_vector(j,1);
        end 
        eq_result = z_vector(i,1);
        x_entry = (eq_result - sum)/Upper_triangular_matrix(i,i);
        value_vector(i,1) = x_entry;
    end
    disp('solution after first step (z vector) is as follows:')
    disp(z_vector);
    disp('solution for the system is as follows:')
    disp(value_vector);

end