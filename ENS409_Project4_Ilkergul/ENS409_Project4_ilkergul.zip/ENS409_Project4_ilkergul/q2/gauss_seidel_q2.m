function gauss_seidel_q2(A,b)
    disp('------- Gauss-Seidel -------');
    [row,col] = size(A);
    exact_result = A\b;
    tol = 1;
    iter = 1;
    X = zeros(row,30);
    X(:,1) = zeros(row,1);
    while (tol > 10^(-4) && iter < 71)
        iter = iter + 1;
        for i=1:row
            X(i,iter) = b(i);
            for j = 1:row
                if(i ~= j)
                    if(j<i)
                        X(i,iter) = X(i,iter)-(A(i,j)*X(j, iter));
                    else
                        X(i,iter) = X(i,iter)-(A(i,j)*X(j, iter-1));
                    end
                    
                end
            end
            X(i,iter) = X(i,iter)/A(i,i);
        end
        
        Error = abs(exact_result - X(:,iter));
        Relative_error = abs(X(:,iter-1)-X(:,iter));
%         disp(iter -1);
%         disp('Absoulute error of each variable with respect to exact value by the \\ operation:')
%         disp(Error);
%         disp('Relative error of each variable with respect to exact value by the \\ operation:')
%         disp(Relative_error);
        tol = max(Relative_error);
    end
    if(iter ~= 51)
        disp('Iteration number is as follows:'); 
        disp(iter);
    end
    disp('Gauss-Seidel estimate values are as follows:');
    disp(X(:,iter));

end