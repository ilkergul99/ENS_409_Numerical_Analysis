function jacobi_q2(A,b)
    disp('------- Jacobi Iterative Method -------')
    [row,col] = size(A);
    m = row;
    X0 = zeros(row,1);
    exact_result = A\b;
    D = eye(row);
    for i = 1:row
        D(i,i) = A(i,i);
    end
    disp('Diagonal matrix of Jacobi:');
    disp(D);
    
    L = zeros(row,row);
    if(m == 3)
        L(2,1) = -A(2,1);
        L(3,1) = -A(3,1);
        L(3,2) = -A(3,2);

    end
    if(m == 7)
        L(2,1) = -A(2,1);
        L(3,1) = -A(3,1);
        L(4,1) = -A(4,1);
        L(5,1) = -A(5,1);
        L(6,1) = -A(6,1);
        L(7,1) = -A(7,1);
        
        L(3,2) = -A(3,2);
        L(4,2) = -A(4,2);
        L(5,2) = -A(5,2);
        L(6,2) = -A(6,2);
        L(7,2) = -A(7,2);
        
        L(4,3) = -A(4,3);
        L(5,3) = -A(5,3);
        L(6,3) = -A(6,3);
        L(7,3) = -A(7,3);
        
        L(5,4) = -A(5,4);
        L(6,4) = -A(6,4);
        L(7,4) = -A(7,4);
        
        L(6,5) = -A(6,5);
        L(7,5) = -A(7,5);
        
        L(7,6) = -A(7,6);
    end
    if(m == 9)
        L(2,1) = -A(2,1);
        L(3,1) = -A(3,1);
        L(4,1) = -A(4,1);
        L(5,1) = -A(5,1);
        L(6,1) = -A(6,1);
        L(7,1) = -A(7,1);
        L(8,1) = -A(8,1);
        L(9,1) = -A(9,1);
        
        L(3,2) = -A(3,2);
        L(4,2) = -A(4,2);
        L(5,2) = -A(5,2);
        L(6,2) = -A(6,2);
        L(7,2) = -A(7,2);
        L(8,2) = -A(8,2);
        L(9,2) = -A(9,2);
        
        L(4,3) = -A(4,3);
        L(5,3) = -A(5,3);
        L(6,3) = -A(6,3);
        L(7,3) = -A(7,3);
        L(8,3) = -A(8,3);
        L(9,3) = -A(9,3);
        
        L(5,4) = -A(5,4);
        L(6,4) = -A(6,4);
        L(7,4) = -A(7,4);
        L(8,4) = -A(8,4);
        L(9,4) = -A(9,4);
        
        L(6,5) = -A(6,5);
        L(7,5) = -A(7,5);
        L(8,5) = -A(8,5);
        L(9,5) = -A(9,5);
        
        L(7,6) = -A(7,6);
        L(8,6) = -A(8,6);
        L(9,6) = -A(9,6);
        
        L(8,7) = -A(8,7);
        L(9,7) = -A(9,7);

        L(9,8) = -A(9,8);
    end

    disp('Lower Triangular matrix of Jacobi:');
    disp(L);
    
    U = zeros(row,row);
    for i = 1:row
        for j = i+1:row
            U(i,j) = -A(i,j);
        end
    end
    disp('Upper Triangular matrix of Jacobi:');
    disp(U);
    
    tol = 1;
    iter = 0;
    temp = L+U;
    JacobiEstimate = [];
    while (tol > 10^(-4) && iter < 50)
        iter = iter + 1;
        JacobiEstimate = D\temp*X0 + D\b;
        Error = abs(X0 - JacobiEstimate);
%         disp(iter)
%         disp('Absoulute error of each variable with respect to exact value by the \ operation:')
%         disp(Error);
        tol = max(Error);
        X0 = JacobiEstimate;
        
    end
    if(iter ~= 50)
        disp('Iteration number is as follows:'); 
        disp(iter);
    end
    disp('Jacobi estimate values are as follows:');
    disp(JacobiEstimate);
end