clear;
clc;
rand('seed', 6352);
A1 = rand(3,3);
b1 = rand(3,1);
A2 = rand(7,7);
b2 = rand(7,1);
A3 = rand(9,9);
b3 = rand(9,1);
result = A2\b2;
fprintf("A matrix:\n")
disp(A2);
fprintf("Exact result by the \\ operation:\n")
disp(result);
gaussianelimination_q2(A2,b2);
fprintf("\n")
ludecomposition_q2(A2,b2); 
fprintf("\n")
jacobi_q2(A2,b2);
fprintf("\n")
gauss_seidel_q2(A2,b2);

disp(inv(A1));
disp(inv(A2));
disp(inv(A3));
