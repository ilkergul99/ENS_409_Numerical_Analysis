function q3newton(x2, y2, x3, y3)
    myfunc = @(x)sqrt(1 + x^2);
    degree2 = length(x2) -1;
    DD2 = zeros(length(x2),length(y2));
    DD2(:,1) = y2;
    for k = 2: degree2 + 1
        for i = 1: degree2 + 2 - k 
            DD2(i, k) = (DD2(i+1,k-1)-DD2(i, k-1))/(x2(i + k -1) - x2(i));
        end
    end
    interpol2 = @(x)DD2(1,1) +DD2(1,2)*(x- x2(1)) + DD2(1,3)*(x- x2(1))*(x- x2(2)) + DD2(1,4)*(x- x2(1))*(x- x2(2))*(x - x2(3)) + DD2(1,5)*(x- x2(1))*(x- x2(2))*(x - x2(3))*(x-x2(4)) + DD2(1,6)*(x- x2(1))*(x- x2(2))*(x - x2(3))*(x-x2(4))*(x-x2(5));

    degree3 = length(x3) -1;
    DD3 = zeros(length(x3),length(y3));
    DD3(:,1) = y3;
    for k = 2: degree3 + 1
        for i = 1: degree3 + 2 - k 
            DD3(i, k) = (DD3(i+1,k-1)-DD3(i, k-1))/(x3(i + k -1) - x3(i));
        end
    end
    interpol3 = @(x)DD3(1,1) +DD3(1,2)*(x- x3(1)) + DD3(1,3)*(x- x3(1))*(x- x3(2)) + DD3(1,4)*(x- x3(1))*(x- x3(2))*(x - x3(3)) + DD3(1,5)*(x- x3(1))*(x- x3(2))*(x - x3(3))*(x-x3(4)) + DD3(1,6)*(x- x3(1))*(x- x3(2))*(x - x3(3))*(x-x3(4))*(x-x3(5)) + DD3(1,7)*(x- x3(1))*(x- x3(2))*(x - x3(3))*(x-x3(4))*(x-x3(5))*(x-x3(6)) + DD3(1,8)*(x- x3(1))*(x- x3(2))*(x - x3(3))*(x-x3(4))*(x-x3(5))*(x-x3(6))*(x-x3(7)) + DD3(1,9)*(x- x3(1))*(x- x3(2))*(x - x3(3))*(x-x3(4))*(x-x3(5))*(x-x3(6))*(x-x3(7))*(x-x3(8)) + DD3(1,10)*(x- x3(1))*(x- x3(2))*(x - x3(3))*(x-x3(4))*(x-x3(5))*(x-x3(6))*(x-x3(7))*(x-x3(8))*(x-x3(9)) + DD3(1,11)*(x- x3(1))*(x- x3(2))*(x - x3(3))*(x-x3(4))*(x-x3(5))*(x-x3(6))*(x-x3(7))*(x-x3(8))*(x-x3(9))*(x-x3(10));
    funcx = -1:0.05:1;
    funcy1 = [];
    funcy2 = [];
    funcy3 = [];
    for i = 1: length(funcx)
        funcy1(i) = myfunc(funcx(i));
        funcy2(i) = interpol2(funcx(i)); 
        funcy3(i) = interpol3(funcx(i)); 
           
    end
    error1 = [];
    error2 = [];
    for i = 1: length(funcx) 
        error1(i) = funcy1(i) - funcy2(i);
        error2(i) = funcy1(i) - funcy3(i);
    end
    
    plot(funcx,error1,'DisplayName','error 5th degree newton polynmomial function');
    hold on
    plot(funcx,error2, 'DisplayName',' error 10th degree newton polynmomial interpolation')
%     plot(funcx,funcy1,'DisplayName','original function');
%     hold on
%     plot(funcx,funcy2,'DisplayName','5th degree interpolation')
%     hold on
%     plot(funcx,funcy3, 'DisplayName','10th degree interpolation')
    grid on
    legend
    
end