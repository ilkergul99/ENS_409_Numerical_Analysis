%% Newton Interpolation
myf = @(x)sqrt(1 + x^2);
x1 = [];
y1 = [];
x2 = [];
y2 = [];
n = 5;
for i = 1: n+1 
    x1(i) = -1 + (2*(i-1)/n);
end
for j = 1: length(x1)
    y1(j) = myf(x1(j));
end
n = 10;
for i = 1: n+1 
    x2(i) = -1 + (2*(i-1)/n);
end
for j = 1: length(x2)
    y2(j) = myf(x2(j));
end

x3 = [];
y3 = [];
x4 = [];
y4 = [];
n = 5;
for i = 1: n+1 
    x3(i) = cos((2*(i-1)/n));
end
for j = 1: length(x3)
    y3(j) = myf(x3(j));
end
n = 10;
for i = 1: n+1 
    x4(i) = cos((2*(i-1)/n));
end
for j = 1: length(x4)
    y4(j) = myf(x4(j));
end
q3newton(x3, y3, x4, y4);
%% Lagrange Interpolation
myf = @(x)sqrt(1 + x^2);
x1 = [];
y1 = [];
x2 = [];
y2 = [];
n = 5;
for i = 1: n+1 
    x1(i) = -1 + (2*(i-1)/n);
end
for j = 1: length(x1)
    y1(j) = myf(x1(j));
end
n = 10;
for i = 1: n+1 
    x2(i) = -1 + (2*(i-1)/n);
end
for j = 1: length(x2)
    y2(j) = myf(x2(j));
end

x3 = [];
y3 = [];
x4 = [];
y4 = [];
n = 5;
for i = 1: n+1 
    x3(i) = cos((2*(i-1)/n));
end
for j = 1: length(x3)
    y3(j) = myf(x3(j));
end
n = 10;
for i = 1: n+1 
    x4(i) = cos((2*(i-1)/n));
end
for j = 1: length(x4)
    y4(j) = myf(x4(j));
end
q3lagrange(x3, y3, x4, y4);
%% Hermite Interpolation
myf = @(x)sqrt(1 + x^2);
hd = @(x)x/sqrt(1 + x^2);
x1 = [];
y1 = [];
y1dev = [];
x2 = [];
y2 = [];
y2dev = [];
n = 5;
for i = 1: n+1 
    x1(i) = -1 + (2*(i-1)/n);
end
for j = 1: length(x1)
    y1(j) = myf(x1(j));
    y1dev(j) = hd(x1(j));
end
n = 10;
for i = 1: n+1 
    x2(i) = -1 + (2*(i-1)/n);
end
for j = 1: length(x2)
    y2(j) = myf(x2(j));
    y2dev(j) = hd(x2(j));
end

x3 = [];
y3 = [];
y3dev = [];
x4 = [];
y4 = [];
y4dev = [];
n = 5;
for i = 1: n+1 
    x3(i) = cos((2*(i-1)/n));
end
for j = 1: length(x3)
    y3(j) = myf(x3(j));
    y3dev(j) = hd(x3(j));
end
n = 10;
for i = 1: n+1 
    x4(i) = cos((2*(i-1)/n));
end
for j = 1: length(x4)
    y4(j) = myf(x4(j));
    y4dev(j) = hd(x4(j));
end
q3hermite(x3, y3, y3dev, x4, y4, y4dev);