%% Newton Interpolation
myf = @(x)1/(1+(x*x));
x1 = [-5,5];
y1 = [];
for i = 1: length(x1)
    y1(i) = myf(x1(i));
end
x2 = [-5, -3, -1, 1, 3, 5];
y2 = [];
for i = 1: length(x2)
    y2(i) = myf(x2(i));
end
x3 = [-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5];
y3 = [];
for i = 1: length(x3)
    y3(i) = myf(x3(i));
end
q2newton(x1, y1, x2, y2, x3, y3);
%% Lagrange Interpolation
myf = @(x)1/(1+(x*x));
x1 = [-5,5];
y1 = [];
for i = 1: length(x1)
    y1(i) = myf(x1(i));
end
x2 = [-5, -3, -1, 1, 3, 5];
y2 = [];
for i = 1: length(x2)
    y2(i) = myf(x2(i));
end
x3 = [-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5];
y3 = [];
for i = 1: length(x3)
    y3(i) = myf(x3(i));
end
q2lagrange(x1, y1, x2, y2, x3, y3);
%% Hermite Interpolation
myf = @(x)1/(1+(x*x));
fd = @(x)-2*x/(x^2+1)^2;
x1 = [-5,5];
y1 = [];
y1dev = [];
for i = 1: length(x1)
    y1(i) = myf(x1(i));
    y1dev(i) = fd(x1(i));
end
x2 = [-5, -3, -1, 1, 3, 5];
y2 = [];
y2dev = [];
for i = 1: length(x2)
    y2(i) = myf(x2(i));
    y2dev(i) = fd(x2(i));
end
x3 = [-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5];
y3 = [];
y3dev = [];
for i = 1: length(x3)
    y3(i) = myf(x3(i));
    y3dev(i) = fd(x3(i));
end
q2hermite(x1, y1,y1dev, x2, y2,y2dev, x3, y3, y3dev);