function q2newton(x1, y1, x2, y2, x3, y3)
    myfunc = @(x)(1)/(1+ x^2);
    degree1 = length(x1) -1;
    DD1 = zeros(length(x1),length(y1));
    DD1(:,1) = y1;
    for k = 2: degree1 + 1
        for i = 1: degree1 + 2 - k 
            DD1(i, k) = (DD1(i+1,k-1)-DD1(i, k-1))/(x1(i + k -1) - x1(i));
        end
    end
    interpol = @(x)DD1(1,1) +DD1(1,2)*(x- x1(1)); 
       
    degree2 = length(x2) -1;
    DD2 = zeros(length(x2),length(y2));
    DD2(:,1) = y2;
    for k = 2: degree2 + 1
        for i = 1: degree2 + 2 - k 
            DD2(i, k) = (DD2(i+1,k-1)-DD2(i, k-1))/(x2(i + k -1) - x2(i));
        end
    end
    interpol2 = @(x)DD2(1,1) +DD2(1,2)*(x- x2(1)) + DD2(1,3)*(x- x2(1))*(x- x2(2)) + DD2(1,4)*(x- x2(1))*(x- x2(2))*(x - x2(3)) + DD2(1,5)*(x- x2(1))*(x- x2(2))*(x - x2(3))*(x-x2(4)) + DD2(1,6)*(x- x2(1))*(x- x2(2))*(x - x2(3))*(x-x2(4))*(x-x2(5));

    degree3 = length(x3) -1;
    DD3 = zeros(length(x3),length(y3));
    DD3(:,1) = y3;
    for k = 2: degree3 + 1
        for i = 1: degree3 + 2 - k 
            DD3(i, k) = (DD3(i+1,k-1)-DD3(i, k-1))/(x3(i + k -1) - x3(i));
        end
    end
    interpol3 = @(x)DD3(1,1) +DD3(1,2)*(x- x3(1)) + DD3(1,3)*(x- x3(1))*(x- x3(2)) + DD3(1,4)*(x- x3(1))*(x- x3(2))*(x - x3(3)) + DD3(1,5)*(x- x3(1))*(x- x3(2))*(x - x3(3))*(x-x3(4)) + DD3(1,6)*(x- x3(1))*(x- x3(2))*(x - x3(3))*(x-x3(4))*(x-x3(5)) + DD3(1,7)*(x- x3(1))*(x- x3(2))*(x - x3(3))*(x-x3(4))*(x-x3(5))*(x-x3(6)) + DD3(1,8)*(x- x3(1))*(x- x3(2))*(x - x3(3))*(x-x3(4))*(x-x3(5))*(x-x3(6))*(x-x3(7)) + DD3(1,9)*(x- x3(1))*(x- x3(2))*(x - x3(3))*(x-x3(4))*(x-x3(5))*(x-x3(6))*(x-x3(7))*(x-x3(8)) + DD3(1,10)*(x- x3(1))*(x- x3(2))*(x - x3(3))*(x-x3(4))*(x-x3(5))*(x-x3(6))*(x-x3(7))*(x-x3(8))*(x-x3(9)) + DD3(1,11)*(x- x3(1))*(x- x3(2))*(x - x3(3))*(x-x3(4))*(x-x3(5))*(x-x3(6))*(x-x3(7))*(x-x3(8))*(x-x3(9))*(x-x3(10));
    
    funcx = -5:0.1:5;
    funcy1 = [];
    funcy2 = [];
    funcy3 = [];
    funcy4 = [];
    for i = 1: length(funcx)
        funcy1(i) = myfunc(funcx(i));
        funcy2(i) = interpol(funcx(i)); 
        funcy3(i) = interpol2(funcx(i)); 
        funcy4(i) = interpol3(funcx(i));    
    end
   
  
    plot(funcx,funcy1,'DisplayName','original function');
    hold on
    plot(funcx,funcy2,'DisplayName','1st degree newton interpolation')
    hold on
    plot(funcx,funcy3,'DisplayName','5th degree newton interpolation')
    hold on
    plot(funcx,funcy4, 'DisplayName','10th degree newton interpolation')
    grid on
    legend
    
    
end