%%% ENS409 Project2
%% Newton Interpolation
x = [1, 1.05, 1.07, 1.09, 1.2, 1.23];
y = [0.76579, 0.83543, 0.85893, 0.87956, 0.92924, 0.91952];
newtoninterpolation(1.03, x, y);

%% Lagrange Interpolation
x = [1, 1.05, 1.07, 1.09, 1.2, 1.23];
y = [0.76579, 0.83543, 0.85893, 0.87956, 0.92924, 0.91952];
Lagrangeinterpolation(1.03, x, y);
%% Hermite Interpolation
x = [1, 1.05, 1.07, 1.09, 1.2, 1.23];
y = [0.76579, 0.83543, 0.85893, 0.87956, 0.92924, 0.91952];
ydev = [1.5316, 1.2422, 1.1056, 0.95608, -0.13358, -0.52159];
Hermiteinterpolation(1.03, x, y, ydev);