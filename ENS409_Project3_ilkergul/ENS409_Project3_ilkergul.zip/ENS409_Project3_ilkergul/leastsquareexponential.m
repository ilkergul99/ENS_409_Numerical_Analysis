function leastsquareexponential(Xtrain, Ytrain)
   n = length(Xtrain); 
   logy = log(Ytrain);
   
   sum1 = sum(Xtrain);
   sum2 = sum(logy);
   sum3 = sum(Xtrain.*Xtrain);
   sum4 = sum(Xtrain.*logy);
   
   a1 = (n*sum4 - (sum1*sum2))/(n*sum3 -(sum1*sum1));
   a0 = (sum2 - (a1*sum1))/n;
   
   A = exp(a0);
   B = a1;
   lse = @(x)A*exp(B*x);
   abserror = abs(Ytrain - lse(Xtrain));
   relative = abserror./abs(Ytrain);
   fprintf('The A coeffcient is %.6f', A);
   fprintf('\n')
   fprintf('The B coeffcient is %.6f', B);
   fprintf('\n\n')
   fprintf('The max absolute error is %.6f', max(abserror));
   fprintf('\n')
   fprintf('The max absolute relative error is %.6f', max(relative));
   fprintf('\n')
   plot(Xtrain, Ytrain, 'DisplayName','Original Train Data');
   hold on;
   plot(Xtrain, lse(Xtrain), 'DisplayName','exponential polynomial line');
   grid on;
   legend;
   hold off;
   
end