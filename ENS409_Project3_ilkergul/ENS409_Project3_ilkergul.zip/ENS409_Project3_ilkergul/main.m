clear;
clc;


%% best fit line in the least squares sense,  correlation coefficient r
load('proj3data.mat');
Xtrain = x(1,1:450);
Ytrain = y(1,1:450);

coefficients(Xtrain, Ytrain);   

%% Obtain the least squares polynomial
load('proj3data.mat');
Xtrain = x(1,1:450);
Ytrain = y(1,1:450);
leastsquarepolynomial(Xtrain, Ytrain);

%% Obtain the least squares exponential fit 
load('proj3data.mat');
Xtrain = x(1,1:450);
Ytrain = y(1,1:450);
leastsquareexponential(Xtrain, Ytrain);

%% Evaluate your models
load('proj3data.mat');
Xtrain = x(1,1:450);
Ytrain = y(1,1:450);
Xtest = x(1,451:601);
Ytest = y(1,451:601);

[error1, relerror1] = coefficientstest(Xtrain, Ytrain, Xtest, Ytest); 
%comment out to test the function
[z1, z2, z3, z4, z5, z6, z7, z8] = leastsquarepolynomialtest(Xtrain, Ytrain, Xtest, Ytest); 

[error3, relerror3] =leastsquareexponentialtest(Xtrain, Ytrain, Xtest, Ytest);
%comment out totest the function
figure
subplot(1,2,1)
plot(Xtest, error1, 'DisplayName','Part 1 line absolute error');
hold on;
plot(Xtest, z1, 'DisplayName','Part 2 2nd degree absolute error');
grid on;
plot(Xtest, z3, 'DisplayName','Part 2 5th degree absolute error');
grid on;
% plot(Xtest, z5, 'DisplayName','Part 2 10th degree absolute error');
% grid on;
% plot(Xtest, z7, 'DisplayName','Part 2 30th degree absolute error');
% grid on;
plot(Xtest, error3, 'DisplayName','Exponential polynomial absolute error');
grid on;
legend;
hold off;
subplot(1,2,2)
plot(Xtest, relerror1, 'DisplayName','Part 1 line relative error');
hold on;
plot(Xtest, z2, 'DisplayName','Part 2 2nd degree relative error');
grid on;
plot(Xtest, z4, 'DisplayName','Part 2 5th degree relative error');
grid on;
% plot(Xtest, z6, 'DisplayName','Part 2 10th degree relative error');
% grid on;
% plot(Xtest, z8, 'DisplayName','Part 2 30th degree relative error');
% grid on;
plot(Xtest, relerror3, 'DisplayName','Exponential polynomial relative error');
grid on;
legend;
hold off;

