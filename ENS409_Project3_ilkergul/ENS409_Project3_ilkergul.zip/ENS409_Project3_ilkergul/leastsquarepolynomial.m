function leastsquarepolynomial(Xtrain, Ytrain)
    n = length(Xtrain);
    sum1 = sum(Xtrain);
    sum2 = sum(Ytrain);
    sum3 = sum(Xtrain.*Xtrain);
    sum4 = sum(Xtrain.^3);
    sum5 = sum(Xtrain.^4);
    sum6 = sum(Xtrain.*Ytrain);
    sum7 = sum(Xtrain.^2.*Ytrain);
    
    secondpolmat = [n sum1 sum3;
              sum1 sum3 sum4;
              sum3 sum4 sum5];
    result = [sum2; sum6; sum7];
    
    fifthpolmat = zeros(6,6);
    tenthpolmat = zeros(11,11);
    thirtiethpolmat = zeros(31,31);
    result5 = zeros(6,1);
    result10 = zeros(11,1);
    result30 = zeros(31,1);
    for a = 1:6
        if(a == 1)
            result5(a,1) = sum(Ytrain);
        else
            result5(a,1) = sum((Xtrain.^(a-1)).*Ytrain);
        end
    end
    for a = 1:11
        if(a == 1)
            result10(a,1) = sum(Ytrain);
        else
            result10(a,1) = sum((Xtrain.^(a-1)).*Ytrain);
        end
    end
    for a = 1:31
        if(a == 1)
            result30(a,1) = sum(Ytrain);
        else
            result30(a,1) = sum((Xtrain.^(a-1)).*Ytrain);
        end
    end
    
    for i=1:6
        for j=1:6
            if(i+j -2 == 0)
                fifthpolmat(i,j) = n;
            else
                fifthpolmat(i,j) = sum(Xtrain.^(i+j-2));
            end
        end
    end
    for i=1:11
        for j=1:11
            if(i+j -2 == 0)
                tenthpolmat(i,j) = n;
            else
                tenthpolmat(i,j) = sum(Xtrain.^(i+j-2));
            end
        end
    end
    
    for i=1:31
        for j=1:31
            if(i+j -2 == 0)
                thirtiethpolmat(i,j) = n;
            else
                thirtiethpolmat(i,j) = sum(Xtrain.^(i+j-2));
            end
        end
    end
          
    coefficients2 = secondpolmat\result;
    lse = @(x)coefficients2(3)*(x.^2) + coefficients2(2)*x + coefficients2(1);
    
    coefficients5 = fifthpolmat\result5;
    lse5 = @(x)coefficients5(6)*(x.^5) + coefficients5(5)*(x.^4) + coefficients5(4)*(x.^3) + coefficients5(3)*(x.^2) + coefficients5(2)*x + coefficients5(1);
    
    coefficients10 = tenthpolmat\result10;
    lse10 = @(x)coefficients10(11)*(x.^10) +coefficients10(10)*(x.^9) +coefficients10(9)*(x.^8) ...
        +coefficients10(8)*(x.^7) +coefficients10(7)*(x.^6) +coefficients10(6)*(x.^5) ... 
        +coefficients10(5)*(x.^4) +coefficients10(4)*(x.^3) +coefficients10(3)*(x.^2) ...
        + coefficients10(2)*x + coefficients10(1);
    
    coefficients30 = thirtiethpolmat\result30;
    lse30 = @(x)coefficients30(31)*(x.^30)+ coefficients30(30)*(x.^29) + coefficients30(29)*(x.^28) + coefficients30(28)*(x.^27)...
        + coefficients30(27)*(x.^26) + coefficients30(26)*(x.^25) + coefficients30(25)*(x.^24)...
        + coefficients30(24)*(x.^23) + coefficients30(23)*(x.^22) + coefficients30(22)*(x.^21)...
        + coefficients30(21)*(x.^20) + coefficients30(20)*(x.^19) + coefficients30(19)*(x.^18)...
        + coefficients30(18)*(x.^17) + coefficients30(17)*(x.^16) + coefficients30(16)*(x.^15)...
        + coefficients30(15)*(x.^14) + coefficients30(14)*(x.^13)+ coefficients30(13)*(x.^12)...
        + coefficients30(12)*(x.^11) + coefficients30(11)*(x.^10) + coefficients30(10)*(x.^9)...
        + coefficients30(9)*(x.^8) + coefficients30(8)*(x.^7) + coefficients30(7)*(x.^6)...
        + coefficients30(6)*(x.^5) + coefficients30(5)*(x.^4) + coefficients30(4)*(x.^3)...
        + coefficients30(3)*(x.^2) + coefficients30(2)*x + coefficients30(1);
    
    p2 = polyfit(Xtrain, Ytrain, 2);
    p5 = polyfit(Xtrain, Ytrain, 5);
    p10 = polyfit(Xtrain, Ytrain, 10);
    p30 = polyfit(Xtrain, Ytrain, 30);
    f2 = polyval(p2,Xtrain);
    f5 = polyval(p5,Xtrain);
    f10 = polyval(p10,Xtrain);
    f30 = polyval(p30,Xtrain);
    
    abserror30 = abs(Ytrain - lse30(Xtrain));
    abserror10 = abs(Ytrain - lse10(Xtrain));
    abserror5 = abs(Ytrain - lse5(Xtrain));
    abserror2 = abs(Ytrain - lse(Xtrain));
    
    relative30 = abserror30./abs(Ytrain);
    relative10 = abserror10./abs(Ytrain);
    relative5 = abserror5./abs(Ytrain);
    relative2 = abserror2./abs(Ytrain);
    
    fprintf('Second Degree Least Square Polynomial\n');
    fprintf('The a2 coeffcient is %.6f', coefficients2(3));
    fprintf('\n')
    fprintf('The a1 coeffcient is %.6f', coefficients2(2));
    fprintf('\n')
    fprintf('The a0 coeffcient is %.6f', coefficients2(1));
    fprintf('\n\n')
    
    fprintf('Fifth Degree Least Square Polynomial\n');
    fprintf('The a5 coeffcient is %.6f', coefficients5(6));
    fprintf('\n')
    fprintf('The a4 coeffcient is %.6f', coefficients5(5));
    fprintf('\n')
    fprintf('The a3 coeffcient is %.6f', coefficients5(4));
    fprintf('\n')
    fprintf('The a2 coeffcient is %.6f', coefficients5(3));
    fprintf('\n')
    fprintf('The a1 coeffcient is %.6f', coefficients5(2));
    fprintf('\n')
    fprintf('The a0 coeffcient is %.6f', coefficients5(1));
    fprintf('\n\n')
    
    fprintf('Tenth Degree Least Square Polynomial\n');
    fprintf('The a10 coeffcient is %.6f', coefficients10(11));
    fprintf('\n')
    fprintf('The a9 coeffcient is %.6f', coefficients10(10));
    fprintf('\n')
    fprintf('The a8 coeffcient is %.6f', coefficients10(9));
    fprintf('\n')
    fprintf('The a7 coeffcient is %.6f', coefficients10(8));
    fprintf('\n')
    fprintf('The a6 coeffcient is %.6f', coefficients10(7));
    fprintf('\n')
    fprintf('The a5 coeffcient is %.6f', coefficients10(6));
    fprintf('\n')
    fprintf('The a4 coeffcient is %.6f', coefficients10(5));
    fprintf('\n')
    fprintf('The a3 coeffcient is %.6f', coefficients10(4));
    fprintf('\n')
    fprintf('The a2 coeffcient is %.6f', coefficients10(3));
    fprintf('\n')
    fprintf('The a1 coeffcient is %.6f', coefficients10(2));
    fprintf('\n')
    fprintf('The a0 coeffcient is %.6f', coefficients10(1));
    fprintf('\n\n')
    
    fprintf('Thirtieth Degree Least Square Polynomial\n');
    fprintf('The a30 coeffcient is %.6f', coefficients30(31));
    fprintf('\n')
    fprintf('The a29 coeffcient is %.6f', coefficients30(30));
    fprintf('\n')
    fprintf('The a28 coeffcient is %.6f', coefficients30(29));
    fprintf('\n')
    fprintf('The a27 coeffcient is %.6f', coefficients30(28));
    fprintf('\n')
    fprintf('The a26 coeffcient is %.6f', coefficients30(27));
    fprintf('\n')
    fprintf('The a25 coeffcient is %.6f', coefficients30(26));
    fprintf('\n')
    fprintf('The a24 coeffcient is %.6f', coefficients30(25));
    fprintf('\n')
    fprintf('The a23 coeffcient is %.6f', coefficients30(24));
    fprintf('\n')
    fprintf('The a22 coeffcient is %.6f', coefficients30(23));
    fprintf('\n')
    fprintf('The a21 coeffcient is %.6f', coefficients30(22));
    fprintf('\n')
    fprintf('The a20 coeffcient is %.6f', coefficients30(21));
    fprintf('\n')
    fprintf('The a19 coeffcient is %.6f', coefficients30(20));
    fprintf('\n')
    fprintf('The a18 coeffcient is %.6f', coefficients30(19));
    fprintf('\n')
    fprintf('The a17 coeffcient is %.6f', coefficients30(18));
    fprintf('\n')
    fprintf('The a16 coeffcient is %.6f', coefficients30(17));
    fprintf('\n')
    fprintf('The a15 coeffcient is %.6f', coefficients30(16));
    fprintf('\n')
    fprintf('The a14 coeffcient is %.6f', coefficients30(15));
    fprintf('\n')
    fprintf('The a13 coeffcient is %.6f', coefficients30(14));
    fprintf('\n')
    fprintf('The a12 coeffcient is %.6f', coefficients30(13));
    fprintf('\n')
    fprintf('The a11 coeffcient is %.6f', coefficients30(12));
    fprintf('\n')
    fprintf('The a10 coeffcient is %.6f', coefficients30(11));
    fprintf('\n')
    fprintf('The a9 coeffcient is %.6f', coefficients30(10));
    fprintf('\n')
    fprintf('The a8 coeffcient is %.6f', coefficients30(9));
    fprintf('\n')
    fprintf('The a7 coeffcient is %.6f', coefficients30(8));
    fprintf('\n')
    fprintf('The a6 coeffcient is %.6f', coefficients30(7));
    fprintf('\n')
    fprintf('The a5 coeffcient is %.6f', coefficients30(6));
    fprintf('\n')
    fprintf('The a4 coeffcient is %.6f', coefficients30(5));
    fprintf('\n')
    fprintf('The a3 coeffcient is %.6f', coefficients30(4));
    fprintf('\n')
    fprintf('The a2 coeffcient is %.6f', coefficients30(3));
    fprintf('\n')
    fprintf('The a1 coeffcient is %.6f', coefficients30(2));
    fprintf('\n')
    fprintf('The a0 coeffcient is %.6f', coefficients30(1));
    fprintf('\n\n')
    fprintf('The 2nd degree max absolute error is %.6f', max(abserror2));
    fprintf('\n')
    fprintf('The 2nd degree max absolute relative error is %.6f', max(relative2));
    fprintf('\n')
    fprintf('The 5th degree max absolute error is %.6f', max(abserror5));
    fprintf('\n')
    fprintf('The 5th degree max absolute relative error is %.6f', max(relative5));
    fprintf('\n')
    fprintf('The 10th degree max absolute error is %.6f', max(abserror10));
    fprintf('\n')
    fprintf('The 10th degree max absolute relative error is %.6f', max(relative10));
    fprintf('\n')
    fprintf('The 30th degree max absolute error is %.6f', max(abserror30));
    fprintf('\n')
    fprintf('The 30th degree max absolute relative error is %.6f', max(relative30));
    fprintf('\n')
    plot(Xtrain, Ytrain, 'DisplayName','Original Train Data');
    hold on;
%     plot(Xtrain, lse(Xtrain), 'DisplayName','2nd degree least square polynomial');
%     grid on;
    plot(Xtrain, lse5(Xtrain), 'DisplayName','5th degree least square polynomial');
    grid on;
%     plot(Xtrain, lse10(Xtrain), 'DisplayName','10th degree least square polynomial');
%     grid on;
%     plot(Xtrain, lse30(Xtrain), 'DisplayName','30th degree least square polynomial');
%     grid on;
%     plot(Xtrain, f2, 'DisplayName','2nd degree polyfit polynomial');
%     grid on;
    plot(Xtrain, f5, 'DisplayName','5th degree polyfit polynomial');
    grid on;
%     plot(Xtrain, f10, 'DisplayName','10th degree polyfit polynomial');
%     grid on;
%     plot(Xtrain, f30, 'DisplayName','30th degree polyfit polynomial');
%     grid on;
    legend;
    hold off;
end