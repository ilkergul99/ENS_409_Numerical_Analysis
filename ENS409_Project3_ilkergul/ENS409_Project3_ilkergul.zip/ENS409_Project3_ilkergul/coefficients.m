function coefficients(Xtrain, Ytrain)
    [n] = length(Xtrain);
    sum1 = sum(Xtrain);
    sum2 = sum(Ytrain);
    sum3 = sum(Xtrain.*Xtrain);
    sum4 = sum(Xtrain.*Ytrain);
    sum5 = sum(Ytrain.*Ytrain);
    
    a1 = (n*sum4 - (sum1*sum2))/(n*sum3 -(sum1*sum1));
    a0 = (sum2 - (a1*sum1))/n;
    lse = @(x)a1*x + a0;
    
    r = (n*sum4 - (sum1*sum2))/(sqrt(n*sum3 -(sum1*sum1))*sqrt(n*sum5 -(sum2*sum2)));
    rsquare = r*r;
    % If the value of r=1, that corresponds to a perfect fit to the data
    % if the value of r is close to unity, 
    % that corresponds to a good correlation of the fit and the original data.
    fprintf('The a1 coeffcient is %.6f', a1);
    fprintf('\n')
    fprintf('The a0 coeffcient is %.6f', a0);
    fprintf('\n')
    fprintf('The correlation coefficient r is %.6f', r);
    fprintf('\n')
    fprintf('The original uncertainty explained by the linear model is %.6f', rsquare);
    fprintf('\n')
    plot(Xtrain, Ytrain, 'DisplayName','Original Train Data');
    hold on;
    plot(Xtrain, lse(Xtrain), 'DisplayName','1st degree best fit line');
    grid on;
    legend;
    hold off;
end